/*
azspark
one12546@126.com
*/
#include "cachelab.h"
#include <getopt.h> 
#include <stdlib.h> 
#include <unistd.h>

int main()
{
    printSummary(0, 0, 0);
    return 0;
}
